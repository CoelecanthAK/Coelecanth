import React, { useEffect, useMemo, useState } from "react";

const LEVELS = [
  { lvl: 1, min: 0, max: 199, title: "Deckhand" },
  { lvl: 2, min: 200, max: 399, title: "Able Seaman" },
  { lvl: 3, min: 400, max: 699, title: "Boatswain" },
  { lvl: 4, min: 700, max: 999, title: "First Mate" },
  { lvl: 5, min: 1000, max: Infinity, title: "Captain of the Deep" },
];

const todayKey = () => new Date().toISOString().slice(0, 10);

const isoWeekKey = () => {
  const d = new Date();
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((date - yearStart) / 86400000 + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
};

const load = (k, fallback) => {
  try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
};
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

const DAILY_QUESTS = [
  { id: "breath", label: "Swab the Deck (Breathing)", xp: 10, icon: "⚓" },
  { id: "exercise", label: "Heave the Anchor (Exercise)", xp: 10, icon: "🏋️" },
  { id: "expose", label: "Chart the Stars (Exposure)", xp: 20, icon: "🗺️" },
];

const WEEKLY_QUESTS = [
  { id: "social1", label: "Parley with Strangers (Social Rep #1)", xp: 25, icon: "🗣️" },
  { id: "social2", label: "Portside Exchange (Social Rep #2)", xp: 25, icon: "🤝" },
  { id: "group", label: "Gathering of Mariners (Group Activity)", xp: 50, icon: "🪝" },
  { id: "journal", label: "Captain’s Log (Journal Reflection)", xp: 20, icon: "📜" },
];

const BOSSES = [
  { id: "minnow", title: "Minnow of Silence", when: "Week 2", dc: 8, reward: 100, icon: "🐟" },
  { id: "kraken", title: "Kraken of Gatherings", when: "Week 4", dc: 12, reward: 200, icon: "🦑" },
  { id: "leviathan", title: "Leviathan of Intimacy", when: "Week 6", dc: 14, reward: 300, icon: "🐋" },
  { id: "mirror", title: "Abyssal Mirror", when: "Week 8", dc: 16, reward: 500, icon: "🪞" },
];

const LOOT = [
  { roll: "1–2", name: "Coin of Calm", effect: "+10 XP", bonus: 10 },
  { roll: "3–4", name: "Pearl of Resolve", effect: "+15 XP", bonus: 15 },
  { roll: "5", name: "Map Fragment of Confidence", effect: "+20 XP", bonus: 20 },
  { roll: "6", name: "Compass of Faith", effect: "Advantage next roll", bonus: 0 },
];

function Card({ children, className = "" }) {
  return (
    <div className={`rounded-2xl shadow-lg p-4 bg-white/90 backdrop-blur border border-sky-100 ${className}`}>
      {children}
    </div>
  );
}

function Button({ children, onClick, disabled, variant = "primary" }) {
  const base = "w-full py-2 px-3 rounded-xl text-sm font-semibold transition active:scale-[.99]";
  const variants = {
    primary: "bg-sky-700 text-white disabled:bg-sky-300",
    ghost: "bg-white text-sky-700 border border-sky-200",
    success: "bg-emerald-600 text-white disabled:bg-emerald-300",
  };
  return (
    <button className={`${base} ${variants[variant]}`} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}

function Header({ xp, level }) {
  return (
    <div className="flex items-center gap-3 p-3">
      <div className="text-3xl">⚓</div>
      <div className="flex-1">
        <div className="text-xs uppercase tracking-widest text-sky-800/70">Coelecanth Campaign</div>
        <div className="font-extrabold text-sky-900 text-xl">Captain’s Ledger</div>
        <div className="text-sky-700 text-sm">Level {level.lvl} · {level.title}</div>
      </div>
      <div className="text-right">
        <div className="text-xs text-sky-700/80">XP</div>
        <div className="text-2xl font-black text-sky-900">{xp}</div>
      </div>
    </div>
  );
}

function XPBar({ xp }) {
  const pct = Math.min(100, Math.round(((xp % 1000) / 1000) * 100));
  return (
    <div className="w-full h-3 rounded-full bg-sky-100 overflow-hidden">
      <div className="h-full bg-gradient-to-r from-sky-500 to-cyan-400" style={{ width: `${pct}%` }} />
    </div>
  );
}

function Dice({ onLoot }) {
  const [d20, setD20] = useState(null);
  const [d6, setD6] = useState(null);
  const roll = (sides) => Math.floor(Math.random() * sides) + 1;
  const rollBoth = () => {
    const r20 = roll(20); setD20(r20);
    const r6 = roll(6); setD6(r6);
    if (onLoot) onLoot(r6);
  };
  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-sky-900">Bones of Fate</h3>
        <Button onClick={rollBoth}>Roll d20 + d6</Button>
      </div>
      <div className="grid grid-cols-2 gap-3 text-center">
        <div className="p-3 rounded-xl bg-sky-50 border border-sky-100">
          <div className="text-xs text-sky-600">d20</div>
          <div className="text-3xl font-black text-sky-900">{d20 ?? "—"}</div>
        </div>
        <div className="p-3 rounded-xl bg-sky-50 border border-sky-100">
          <div className="text-xs text-sky-600">d6 (Loot)</div>
          <div className="text-3xl font-black text-sky-900">{d6 ?? "—"}</div>
        </div>
      </div>
      <div className="mt-3 text-xs text-sky-700">
        <p>Use dice as <i>optional overlay</i>. Quests still require real-world action.</p>
      </div>
    </Card>
  );
}

function QuestList({ title, quests, claimedSet, onClaim, subtitle }) {
  return (
    <Card>
      <div className="mb-2">
        <div className="text-xs uppercase tracking-widest text-sky-700/70">{subtitle}</div>
        <h3 className="font-bold text-sky-900 text-lg">{title}</h3>
      </div>
      <div className="space-y-2">
        {quests.map((q) => {
          const done = claimedSet.has(q.id);
          return (
            <div key={q.id} className="flex items-center gap-3 p-2 rounded-xl border border-sky-100 bg-sky-50">
              <div className="text-2xl leading-none">{q.icon}</div>
              <div className="flex-1">
                <div className={`font-semibold ${done ? "line-through text-sky-500" : "text-sky-900"}`}>{q.label}</div>
                <div className="text-xs text-sky-700/80">{q.xp} XP</div>
              </div>
              <Button variant={done ? "ghost" : "primary"} disabled={done} onClick={() => onClaim(q)}>
                {done ? "Claimed" : "Claim"}
              </Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function BossList({ bosses, defeated, onDefeat }) {
  return (
    <Card>
      <h3 className="font-bold text-sky-900 text-lg mb-2">Sea Beasts (Bosses)</h3>
      <div className="space-y-2">
        {bosses.map((b) => {
          const dead = defeated.includes(b.id);
          return (
            <div key={b.id} className="p-3 rounded-xl border border-sky-100 bg-white flex items-center gap-3">
              <div className="text-2xl">{b.icon}</div>
              <div className="flex-1">
                <div className="font-semibold text-sky-900">{b.title} <span className="text-xs text-sky-700/70">({b.when})</span></div>
                <div className="text-xs text-sky-700">DC {b.dc} · Reward {b.reward} XP</div>
              </div>
              <Button variant={dead ? "ghost" : "success"} disabled={dead} onClick={() => onDefeat(b)}>
                {dead ? "Conquered" : "Conquer"}
              </Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

export default function App() {
  const [xp, setXp] = useState(() => load("cxp", 0));
  const [daily, setDaily] = useState(() => load("cdaily", { date: todayKey(), claimed: [] }));
  const [weekly, setWeekly] = useState(() => load("cweekly", { week: isoWeekKey(), claimed: [] }));
  const [bosses, setBosses] = useState(() => load("cboss", []));
  const [log, setLog] = useState(() => load("clog", []));

  useEffect(() => {
    const t = todayKey();
    if (daily.date !== t) setDaily({ date: t, claimed: [] });
    const w = isoWeekKey();
    if (weekly.week !== w) setWeekly({ week: w, claimed: [] });
  }, []);

  useEffect(() => save("cxp", xp), [xp]);
  useEffect(() => save("cdaily", daily), [daily]);
  useEffect(() => save("cweekly", weekly), [weekly]);
  useEffect(() => save("cboss", bosses), [bosses]);
  useEffect(() => save("clog", log), [log]);

  const level = useMemo(() => LEVELS.find(L => xp >= L.min && xp <= L.max) || LEVELS[LEVELS.length-1], [xp]);

  const claimedDaily = useMemo(() => new Set(daily.claimed), [daily]);
  const claimedWeekly = useMemo(() => new Set(weekly.claimed), [weekly]);

  const addLog = (msg) => setLog((old) => [
    `${new Date().toLocaleString()}: ${msg}`,
    ...old.slice(0, 49)
  ]);

  const claimDaily = (q) => {
    if (claimedDaily.has(q.id)) return;
    setDaily((d) => ({ ...d, claimed: [...d.claimed, q.id] }));
    setXp((v) => v + q.xp);
    addLog(`Claimed daily “${q.label}” (+${q.xp} XP).`);
  };
  const claimWeekly = (q) => {
    if (claimedWeekly.has(q.id)) return;
    setWeekly((w) => ({ ...w, claimed: [...w.claimed, q.id] }));
    setXp((v) => v + q.xp);
    addLog(`Completed weekly “${q.label}” (+${q.xp} XP).`);
  };
  const defeatBoss = (b) => {
    if (bosses.includes(b.id)) return;
    setBosses((arr) => [...arr, b.id]);
    setXp((v) => v + b.reward);
    addLog(`Conquered ${b.title} (+${b.reward} XP).`);
  };

  const handleLoot = (roll) => {
    const bonus = roll <= 2 ? 10 : roll <= 4 ? 15 : roll === 5 ? 20 : 0;
    const name = roll <= 2 ? "Coin of Calm" : roll <= 4 ? "Pearl of Resolve" : roll === 5 ? "Map Fragment of Confidence" : "Compass of Faith";
    if (bonus > 0) {
      setXp((v) => v + bonus);
      addLog(`Loot: ${name} (+${bonus} XP).`);
    } else {
      addLog(`Loot: ${name} (Advantage on next roll).`);
    }
  };

  const resetAll = () => {
    if (!confirm("Reset ALL progress?")) return;
    setXp(0); setDaily({ date: todayKey(), claimed: [] }); setWeekly({ week: isoWeekKey(), claimed: [] }); setBosses([]); setLog([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-100 via-cyan-100 to-slate-100 text-slate-900">
      <div className="max-w-md mx-auto p-3 pb-20">
        <Header xp={xp} level={level} />
        <XPBar xp={xp} />

        <div className="mt-4 grid gap-3">
          <QuestList
            title="Daily Quests"
            subtitle={`Ship's Log · ${todayKey()}`}
            quests={DAILY_QUESTS}
            claimedSet={claimedDaily}
            onClaim={claimDaily}
          />

          <QuestList
            title="Weekly Voyages"
            subtitle={`Ledger · ${isoWeekKey()}`}
            quests={WEEKLY_QUESTS}
            claimedSet={claimedWeekly}
            onClaim={claimWeekly}
          />

          <BossList bosses={BOSSES} defeated={bosses} onDefeat={defeatBoss} />

          <Dice onLoot={handleLoot} />

          <Card>
            <h3 className="font-bold text-sky-900 mb-2">Spoils & Relics</h3>
            <ul className="text-sm text-sky-900 list-disc pl-5 space-y-1">
              {LOOT.map((l) => (
                <li key={l.name}><span className="font-semibold">{l.roll}</span>: {l.name} — {l.effect}</li>
              ))}
            </ul>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-sky-900">Captain’s Chronicle</h3>
              <button className="bg-white text-sky-700 border border-sky-200 w-full py-2 px-3 rounded-xl text-sm font-semibold"
                onClick={resetAll}>Reset All</button>
            </div>
            <div className="space-y-1 max-h-48 overflow-auto pr-1">
              {log.length === 0 ? (
                <div className="text-sm text-sky-700">No entries yet. Claim a quest to begin thy chronicle.</div>
              ) : (
                log.map((line, i) => (
                  <div key={i} className="text-xs text-sky-900/90">{line}</div>
                ))
              )}
            </div>
          </Card>

          <div className="text-[10px] text-sky-700/70 text-center mt-2">
            🦑 Tip: Use “Add to Home screen” for app-like launch.
          </div>
        </div>
      </div>
    </div>
  );
}
